#pragma once
#include <bangtal.h>
using namespace bangtal;
class Persol
{

private:
	int xpos;
	int ypos;
	ObjectPtr PersolObject;
	ScenePtr SceneObject;
	bool bHide;
public:

	Persol(int _xpos, int _ypos, ObjectPtr _PersolObject, ScenePtr _SceneObject)
	{
		xpos = _xpos;
		ypos = _ypos;
		PersolObject = _PersolObject;
		SceneObject = _SceneObject;
		bHide = false;
	}
	void setXPos(int _xpos) { xpos = _xpos;}
	void setYPos(int _ypos) { ypos = _ypos; }
	void setHide(bool _bHide) { bHide = _bHide; }
	int getXPos() {return xpos;}
	int getYPos() { return ypos; }
	bool getHide() { return bHide; }
	void ChangePos(Persol* TargetPersol)
	{
		int txpos = xpos;
		int typos = ypos;
		int tbHide = bHide;
		xpos = TargetPersol->xpos;
		ypos = TargetPersol->ypos;

		PersolObject->locate(SceneObject, xpos, ypos);

		TargetPersol->xpos = txpos;
		TargetPersol->ypos = typos;

		TargetPersol->PersolObject->locate(SceneObject, TargetPersol->xpos, TargetPersol->ypos);
	};

	std::shared_ptr<Object> getPersolObject() 
	{
		return PersolObject;
	};

};